package si.inspirited.model.book.page;

import si.inspirited.model.abstractModel.NamedEntity;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author Jesus Lord Almighty
 * at 24.01.2018
 */

@Entity
@Table(name = "pagetypes")
public class PageType extends NamedEntity {


}
