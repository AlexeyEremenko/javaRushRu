package si.inspirited.system.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import si.inspirited.model.book.Book;
import si.inspirited.model.book.BookRepository;

import javax.validation.Valid;
import java.util.Collection;
import java.util.Map;

@Controller
class BookController {

    private static final String VIEWS_BOOK_CREATE_OR_UPDATE_FORM = "books/createOrUpdateBookForm";
    private final BookRepository books;


    @Autowired
    public BookController(BookRepository libraryService) {
        this.books = libraryService;
    }

    @InitBinder
    public void setAllowedFields(WebDataBinder dataBinder) {
        dataBinder.setDisallowedFields("id");
    }

    @GetMapping("/books/new")
    public String initCreationForm(Map<String, Object> model) {
        Book book = new Book();
        model.put("book", book);
        return VIEWS_BOOK_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping("/books/new")
    public String processCreationForm(@Valid Book book, BindingResult result) {
        if (result.hasErrors()) {
            return VIEWS_BOOK_CREATE_OR_UPDATE_FORM;
        } else {
            book.setReadAlready(false);
            this.books.save(book);
            return "redirect:/books/" + book.getId();
        }
    }

    @GetMapping("/books/find")
    public String initFindForm(Map<String, Object> model) {
        model.put("book", new Book());
        return "books/findBooks";
    }


    @GetMapping("/books")
    public String processFindForm(Book book, BindingResult result, Map<String, Object> model) {

        // allow parameterless GET request for /books to return all records
        if (book.getTitle() == null) {
            book.setTitle(""); // empty string signifies broadest possible search
        }

        // find books by title
        Collection<Book> results = this.books.findByTitle(book.getTitle());
        if (results.isEmpty()) {
            // no books found
            //results =
            result.rejectValue("title", "notFound", "not found");
            return "books/findBooks";
        } else if (results.size() == 1) {
            // 1 book found
            book = results.iterator().next();
            return "redirect:/books/" + book.getId();

            //count how many books in result list
        } else {
            // multiple books found
            model.put("selections", results);
            return "books/booksList";
        }
    }

    @GetMapping("/books/{bookId}/edit")
    public String initUpdateBookForm(@PathVariable("bookId") int bookId, Model model) {
        Book book = this.books.findById(bookId);
        model.addAttribute(book);
        return VIEWS_BOOK_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping("/books/{bookId}/edit")
    public String processUpdateBookForm(@Valid Book book, BindingResult result, @PathVariable("bookId") int bookId) {
        if (result.hasErrors()) {
            return VIEWS_BOOK_CREATE_OR_UPDATE_FORM;
        } else {
            book.setId(bookId);
            this.books.save(book);
            return "redirect:/books/{bookId}";
        }
    }

    /**
     * Custom handler for displaying an book.
     *
     * @param bookId the ID of the book to display
     * @return a ModelMap with the model attributes for the view
     */
    @GetMapping("/books/{bookId}")
    public ModelAndView showBook(@PathVariable("bookId") int bookId) {
        ModelAndView mav = new ModelAndView("books/bookDetails");
        mav.addObject(this.books.findById(bookId));
        return mav;
    }

    @GetMapping("/books/{bookId}/read")
    public ModelAndView readBook(@PathVariable("bookId") int bookId) {
        Book readedBook = this.books.findById(bookId);

        readedBook.setReadAlready(true);
        this.books.save(readedBook);
        ModelAndView mav = new ModelAndView("books/readedBook");

        mav.addObject(this.books.findById(bookId));
        return mav;
    }

    @GetMapping("/books/{bookId}/delete")
    public ModelAndView removeBook(@PathVariable("bookId") int bookId) {
        this.books.deleteById(bookId);

        ModelAndView mav = new ModelAndView("books/removedBook");

       // mav.addObject(this.books.findById(bookId));
        return mav;
    }
}