package si.inspirited.model.book.remark;

import org.springframework.dao.DataAccessException;
import org.springframework.data.repository.Repository;
import si.inspirited.model.abstractModel.BaseEntity;

import java.util.List;

public interface RemarkRepository extends Repository<Remark, Integer> {

    /**
     * Save a <code>Remark</code> to the data store, either inserting or updating it.
     *
     * @param remark the <code>Remark</code> to save
     * @see BaseEntity#isNew
     */
    void save(Remark remark) throws DataAccessException;

    List<Remark> findByPageId(Integer petId);
}

