use test;

CREATE TABLE IF NOT EXISTS book (
  id INT(4) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  description VARCHAR(255),
  author VARCHAR(100),
  isbn VARCHAR(20),
  printyear INT,
  readalready BOOLEAN,
  INDEX(name)
) engine=InnoDB;

INSERT IGNORE INTO book VALUES (5, 'Exodus', 'our exodus', 'Holy Spirit', 144, 2000, true);

