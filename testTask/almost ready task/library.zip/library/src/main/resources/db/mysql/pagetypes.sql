use test;

CREATE TABLE IF NOT EXISTS pagetypes (
  id INT(4) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  INDEX(name)
) engine=InnoDB;

INSERT IGNORE INTO pagetypes VALUES (1, 'plain old text');
INSERT IGNORE INTO pagetypes VALUES (2, 'XHTML');
INSERT IGNORE INTO pagetypes VALUES (3, 'java');
INSERT IGNORE INTO pagetypes VALUES (4, 'javascript');
INSERT IGNORE INTO pagetypes VALUES (5, 'scala');
INSERT IGNORE INTO pagetypes VALUES (6, 'alive fresh flow');

